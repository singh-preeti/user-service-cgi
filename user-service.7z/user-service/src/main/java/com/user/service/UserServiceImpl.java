package com.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.user.entity.User;
@Service
public class UserServiceImpl implements UserService {
  //fake list of users
	
	List<User> list=List.of(new User( 101L,"Preeti","9898988"),
			new User(102L,"Rahul","787878"),
			new User(103L,"Zulfaquar","909090"));
	@Override
	public User getUser(Long id) {
		return this.list.stream()
				.filter(user -> 
				user.getUserId()
				.equals(id))
					.findAny()
					.orElse(null);
		
	}

}
